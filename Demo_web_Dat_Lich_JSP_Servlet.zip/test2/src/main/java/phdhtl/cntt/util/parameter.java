package phdhtl.cntt.util;

public class parameter {
	public static final String DB_URL= "jdbc:mysql://localhost:3306/jdbc_cd2";
	public static final String USER_NAME="root";
	public static final String PASSWORD="";
}
