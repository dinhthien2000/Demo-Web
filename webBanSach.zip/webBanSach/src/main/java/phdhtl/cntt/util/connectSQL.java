package phdhtl.cntt.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class connectSQL {
    public static final  String jdbcURL = 
    		"jdbc:sqlserver://localhost:1433;"
    		+ "DatabaseName=bansach;"
    		+ "encrypt = true;"
    		+ "trustServerCertificate=true;"
    		;
    public static final  String USERNAME = "sa";
    public static final  String PASSWORD = "1";
    /*
    public static void main(String[] args) {
    	// test connect
		Connection connection = getConnectionSQLServer();
		System.out.println(connection);
	}*/
    public static Connection getConnectionSQLServer () {
    	
    	Connection connection = null;
    	try {
    		java.security.Security.setProperty("jdk.tls.disabledAlgorithms","");
    		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
    		connection = DriverManager.getConnection(jdbcURL,USERNAME,PASSWORD);
    		System.out.println("success connect");
    		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
    }
}
