package phdhtl.cntt.util;

public class viewGH {
	public static void PrintViewGH(String user) {
		
	}
}
