package phdhtl.cntt.filter;

import java.io.IOException;


import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class gioHang_DonHang_Filter
 */
@WebFilter(urlPatterns ={"/views/giohang.jsp","/views/donhang.jsp"})
public class gioHang_DonHang_Filter extends HttpFilter implements Filter {
       

	private static final long serialVersionUID = 1L;


    public gioHang_DonHang_Filter() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpSession session = request.getSession();
		String user = (String) session.getAttribute("user");
		String path = request.getServletPath();
		
		if(user!= null) {
			switch (path) {
			case "giohang.jsp":
				request.getRequestDispatcher("/views/giohang.jsp").forward(request, response);
				break;
			case "donhang.jsp":
				request.getRequestDispatcher("/views/donhang.jsp").forward(request, response);
				break;
			default:
				break;
			}
		}else {
			request.getRequestDispatcher("/views/index.jsp").forward(request, response);
			
		}
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
