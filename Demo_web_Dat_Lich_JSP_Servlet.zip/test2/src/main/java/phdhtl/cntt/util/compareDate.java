package phdhtl.cntt.util;



public class compareDate {
	public static void main(String[] args) {
		String d1 = "2022-04-25";
		String d = "2022-06-04";
		
		int kq =d1.compareTo(d);
		System.out.println(kq);
		
	}
}
